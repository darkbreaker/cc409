-- phpMyAdmin SQL Dump
-- version 2.10.3
-- http://www.phpmyadmin.net
-- 
-- Servidor: localhost
-- Tiempo de generación: 25-02-2013 a las 23:05:55
-- Versión del servidor: 5.0.51
-- Versión de PHP: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- Base de datos: `maskota`
-- 

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `articulo`
-- 

CREATE TABLE `articulo` (
  `idarticulo` int(11) NOT NULL auto_increment,
  `nombre` varchar(45) default NULL,
  `descripcion` varchar(45) default NULL,
  `precio` float default NULL,
  `cantidad` int(11) default NULL,
  PRIMARY KEY  (`idarticulo`),
  UNIQUE KEY `nombre` (`nombre`,`descripcion`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

-- 
-- Volcar la base de datos para la tabla `articulo`
-- 

INSERT INTO `articulo` (`idarticulo`, `nombre`, `descripcion`, `precio`, `cantidad`) VALUES (2, 'correa chica', 'correa de cuero', 30, 10);
INSERT INTO `articulo` (`idarticulo`, `nombre`, `descripcion`, `precio`, `cantidad`) VALUES (3, 'correa chica', 'correa de nylon', 25, 9);
INSERT INTO `articulo` (`idarticulo`, `nombre`, `descripcion`, `precio`, `cantidad`) VALUES (4, 'correa mediana', 'correa de cuero', 39, 10);
INSERT INTO `articulo` (`idarticulo`, `nombre`, `descripcion`, `precio`, `cantidad`) VALUES (5, 'correa mediana', 'correa de nylon', 31, 9);
INSERT INTO `articulo` (`idarticulo`, `nombre`, `descripcion`, `precio`, `cantidad`) VALUES (6, 'correa grance', 'correa de cuero', 50, 10);
INSERT INTO `articulo` (`idarticulo`, `nombre`, `descripcion`, `precio`, `cantidad`) VALUES (7, 'correa grande', 'correa de nylon', 45, 9);
INSERT INTO `articulo` (`idarticulo`, `nombre`, `descripcion`, `precio`, `cantidad`) VALUES (8, 'iguana verde', 'iguana joven', 50, 0);
INSERT INTO `articulo` (`idarticulo`, `nombre`, `descripcion`, `precio`, `cantidad`) VALUES (9, 'pedeegree cachorro', 'bolsa de kilo', 25, 25);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `cita`
-- 

CREATE TABLE `cita` (
  `idcita` int(11) NOT NULL auto_increment,
  `detalles` varchar(45) default NULL,
  `estado` varchar(45) NOT NULL,
  `inicio` time NOT NULL,
  `fin` time NOT NULL default '20:00:00',
  `fecha` date NOT NULL,
  PRIMARY KEY  (`idcita`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

-- 
-- Volcar la base de datos para la tabla `cita`
-- 

INSERT INTO `cita` (`idcita`, `detalles`, `estado`, `inicio`, `fin`, `fecha`) VALUES (1, NULL, 'terminada', '11:00:00', '12:00:00', '2013-02-25');
INSERT INTO `cita` (`idcita`, `detalles`, `estado`, `inicio`, `fin`, `fecha`) VALUES (2, NULL, 'terminada', '11:00:00', '12:00:00', '2013-02-25');
INSERT INTO `cita` (`idcita`, `detalles`, `estado`, `inicio`, `fin`, `fecha`) VALUES (3, NULL, 'terminada', '12:00:00', '14:00:00', '2013-02-25');
INSERT INTO `cita` (`idcita`, `detalles`, `estado`, `inicio`, `fin`, `fecha`) VALUES (4, NULL, 'terminada', '13:00:00', '20:00:00', '2013-02-25');
INSERT INTO `cita` (`idcita`, `detalles`, `estado`, `inicio`, `fin`, `fecha`) VALUES (5, NULL, 'terminada', '15:00:00', '20:00:00', '2013-02-25');

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `cliente`
-- 

CREATE TABLE `cliente` (
  `idPersona` int(11) NOT NULL auto_increment,
  `nombre` varchar(50) NOT NULL,
  `calle` text NOT NULL,
  `password` varchar(9) NOT NULL,
  `email` varchar(45) NOT NULL,
  PRIMARY KEY  (`idPersona`),
  UNIQUE KEY `email` (`email`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

-- 
-- Volcar la base de datos para la tabla `cliente`
-- 

INSERT INTO `cliente` (`idPersona`, `nombre`, `calle`, `password`, `email`) VALUES (1, 'maria de las marias', 'calle 1 ', '1234', 'maria_marias@correo.com');
INSERT INTO `cliente` (`idPersona`, `nombre`, `calle`, `password`, `email`) VALUES (2, 'juana de las junas', 'calle 1', '1234', 'juana_juanas@correo.com');
INSERT INTO `cliente` (`idPersona`, `nombre`, `calle`, `password`, `email`) VALUES (3, 'pedro perez', 'calle 2', '1234', 'pedro.pedro@correo.com');
INSERT INTO `cliente` (`idPersona`, `nombre`, `calle`, `password`, `email`) VALUES (4, 'juan perez', 'calle 3', '1234', 'j.p@correo.com');
INSERT INTO `cliente` (`idPersona`, `nombre`, `calle`, `password`, `email`) VALUES (5, 'sutano de tal', 'roble 12, alamo', '1234', 'sutanito@correo.com');
INSERT INTO `cliente` (`idPersona`, `nombre`, `calle`, `password`, `email`) VALUES (6, 'fulano de tal', 'zauze 15, el freno', '1234', 'fulanito@correo.com');

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `detalle_cita`
-- 

CREATE TABLE `detalle_cita` (
  `cita_idcita` int(11) NOT NULL,
  `servicio_idservicio` int(11) NOT NULL,
  KEY `fk_cita_has_servicio_servicio1_idx` (`servicio_idservicio`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Volcar la base de datos para la tabla `detalle_cita`
-- 

INSERT INTO `detalle_cita` (`cita_idcita`, `servicio_idservicio`) VALUES (1, 2);
INSERT INTO `detalle_cita` (`cita_idcita`, `servicio_idservicio`) VALUES (2, 2);
INSERT INTO `detalle_cita` (`cita_idcita`, `servicio_idservicio`) VALUES (3, 3);
INSERT INTO `detalle_cita` (`cita_idcita`, `servicio_idservicio`) VALUES (4, 3);
INSERT INTO `detalle_cita` (`cita_idcita`, `servicio_idservicio`) VALUES (5, 4);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `detalle_perecedero`
-- 

CREATE TABLE `detalle_perecedero` (
  `fecha_compra` date NOT NULL,
  `fecha_caducidad` date NOT NULL,
  `cantidad` int(11) default NULL,
  `articulo_idarticulo` int(11) NOT NULL,
  PRIMARY KEY  (`fecha_caducidad`,`fecha_compra`),
  KEY `fk_detalle_perecedero_articulo1_idx` (`articulo_idarticulo`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Volcar la base de datos para la tabla `detalle_perecedero`
-- 

INSERT INTO `detalle_perecedero` (`fecha_compra`, `fecha_caducidad`, `cantidad`, `articulo_idarticulo`) VALUES ('2013-02-01', '2014-02-01', 10, 9);
INSERT INTO `detalle_perecedero` (`fecha_compra`, `fecha_caducidad`, `cantidad`, `articulo_idarticulo`) VALUES ('2013-02-08', '2014-02-15', 2, 9);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `detalle_venta`
-- 

CREATE TABLE `detalle_venta` (
  `articulo_idarticulo` int(11) NOT NULL,
  `nota_venta_idnota_venta` int(11) NOT NULL,
  `precio_venta` float default NULL,
  KEY `fk_articulo_has_nota_venta_nota_venta1_idx` (`nota_venta_idnota_venta`),
  KEY `fk_articulo_has_nota_venta_articulo1_idx` (`articulo_idarticulo`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Volcar la base de datos para la tabla `detalle_venta`
-- 

INSERT INTO `detalle_venta` (`articulo_idarticulo`, `nota_venta_idnota_venta`, `precio_venta`) VALUES (2, 1, 30);
INSERT INTO `detalle_venta` (`articulo_idarticulo`, `nota_venta_idnota_venta`, `precio_venta`) VALUES (2, 2, 30);
INSERT INTO `detalle_venta` (`articulo_idarticulo`, `nota_venta_idnota_venta`, `precio_venta`) VALUES (3, 3, 25);
INSERT INTO `detalle_venta` (`articulo_idarticulo`, `nota_venta_idnota_venta`, `precio_venta`) VALUES (3, 4, 25);
INSERT INTO `detalle_venta` (`articulo_idarticulo`, `nota_venta_idnota_venta`, `precio_venta`) VALUES (4, 5, 39);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `nota_venta`
-- 

CREATE TABLE `nota_venta` (
  `idnota_venta` int(11) NOT NULL auto_increment,
  `total` float default NULL,
  `fecha` date default NULL,
  PRIMARY KEY  (`idnota_venta`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

-- 
-- Volcar la base de datos para la tabla `nota_venta`
-- 

INSERT INTO `nota_venta` (`idnota_venta`, `total`, `fecha`) VALUES (1, 30, '2013-02-25');
INSERT INTO `nota_venta` (`idnota_venta`, `total`, `fecha`) VALUES (2, 30, '2013-02-25');
INSERT INTO `nota_venta` (`idnota_venta`, `total`, `fecha`) VALUES (3, 25, '2013-02-25');
INSERT INTO `nota_venta` (`idnota_venta`, `total`, `fecha`) VALUES (4, 25, '2013-02-25');
INSERT INTO `nota_venta` (`idnota_venta`, `total`, `fecha`) VALUES (5, 39, '2013-02-25');

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `pedido`
-- 

CREATE TABLE `pedido` (
  `fecha` date default NULL,
  `estado` varchar(40) default NULL,
  `Persona_idPersona1` int(11) NOT NULL,
  `articulo_idarticulo` int(11) NOT NULL,
  UNIQUE KEY `fecha` (`fecha`,`Persona_idPersona1`,`articulo_idarticulo`),
  KEY `fk_pedido_Persona1_idx` (`Persona_idPersona1`),
  KEY `fk_pedido_articulo1_idx` (`articulo_idarticulo`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Volcar la base de datos para la tabla `pedido`
-- 

INSERT INTO `pedido` (`fecha`, `estado`, `Persona_idPersona1`, `articulo_idarticulo`) VALUES ('2013-02-24', 'surtido', 1, 1);
INSERT INTO `pedido` (`fecha`, `estado`, `Persona_idPersona1`, `articulo_idarticulo`) VALUES ('2013-02-15', 'ordenado', 3, 3);
INSERT INTO `pedido` (`fecha`, `estado`, `Persona_idPersona1`, `articulo_idarticulo`) VALUES ('2013-02-01', 'cancelado', 2, 8);
INSERT INTO `pedido` (`fecha`, `estado`, `Persona_idPersona1`, `articulo_idarticulo`) VALUES ('2013-02-01', 'surtido', 4, 1);
INSERT INTO `pedido` (`fecha`, `estado`, `Persona_idPersona1`, `articulo_idarticulo`) VALUES ('2013-02-16', 'surtido', 5, 1);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `servicio`
-- 

CREATE TABLE `servicio` (
  `idservicio` int(11) NOT NULL auto_increment,
  `nombre` varchar(45) NOT NULL,
  `descripcion` varchar(45) default NULL,
  `precio` float NOT NULL,
  `tiempo` int(11) NOT NULL,
  PRIMARY KEY  (`idservicio`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

-- 
-- Volcar la base de datos para la tabla `servicio`
-- 

INSERT INTO `servicio` (`idservicio`, `nombre`, `descripcion`, `precio`, `tiempo`) VALUES (1, 'corte de uñas', 'corte para todas las razas', 15, 5);
INSERT INTO `servicio` (`idservicio`, `nombre`, `descripcion`, `precio`, `tiempo`) VALUES (2, 'baño perro chico', 'raza pequeña y gatos', 100, 50);
INSERT INTO `servicio` (`idservicio`, `nombre`, `descripcion`, `precio`, `tiempo`) VALUES (3, 'baño raza mediana', NULL, 120, 60);
INSERT INTO `servicio` (`idservicio`, `nombre`, `descripcion`, `precio`, `tiempo`) VALUES (4, 'baño perro grande', NULL, 150, 70);
INSERT INTO `servicio` (`idservicio`, `nombre`, `descripcion`, `precio`, `tiempo`) VALUES (5, 'perro gigante', 'perro que no cabe en tina', 200, 80);
INSERT INTO `servicio` (`idservicio`, `nombre`, `descripcion`, `precio`, `tiempo`) VALUES (6, 'consulta', NULL, 30, 30);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `telefono`
-- 

CREATE TABLE `telefono` (
  `numero` int(12) NOT NULL,
  `Persona_idPersona` int(11) NOT NULL,
  `tipo` varchar(30) default NULL COMMENT 'especificar /offna, cel,casa',
  KEY `fk_telefono_Persona_idx` (`Persona_idPersona`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Volcar la base de datos para la tabla `telefono`
-- 

INSERT INTO `telefono` (`numero`, `Persona_idPersona`, `tipo`) VALUES (123456, 1, 'casa');
INSERT INTO `telefono` (`numero`, `Persona_idPersona`, `tipo`) VALUES (2147483647, 1, 'celular');
INSERT INTO `telefono` (`numero`, `Persona_idPersona`, `tipo`) VALUES (33448899, 2, 'fijo');
INSERT INTO `telefono` (`numero`, `Persona_idPersona`, `tipo`) VALUES (334488788, 3, 'fijo');
INSERT INTO `telefono` (`numero`, `Persona_idPersona`, `tipo`) VALUES (123456, 3, 'fijo');
INSERT INTO `telefono` (`numero`, `Persona_idPersona`, `tipo`) VALUES (2147483647, 4, 'movil');
INSERT INTO `telefono` (`numero`, `Persona_idPersona`, `tipo`) VALUES (1234567, 4, 'fijo');
INSERT INTO `telefono` (`numero`, `Persona_idPersona`, `tipo`) VALUES (33124456, 5, 'celular');
